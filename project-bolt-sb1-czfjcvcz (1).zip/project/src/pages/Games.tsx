import React from 'react';
import { Trophy, Target, Brain, Coins, Star, Award } from 'lucide-react';
import type { GameState, Achievement } from '../types';

export const Games = () => {
  const [gameState, setGameState] = React.useState<GameState>({
    level: 1,
    experience: 0,
    coins: 100,
    sustainabilityScore: 0
  });

  const [achievements] = React.useState<Achievement[]>([
    {
      id: '1',
      title: 'Novice Gardener',
      description: 'Complete your first game',
      icon: 'trophy',
      reward: { coins: 50, experience: 100 },
      isUnlocked: false,
      progress: 0,
      requiredProgress: 1
    },
    {
      id: '2',
      title: 'Pest Controller',
      description: 'Win 3 pest control games',
      icon: 'shield',
      reward: { coins: 150, experience: 300, items: ['Premium Pesticide'] },
      isUnlocked: false,
      progress: 0,
      requiredProgress: 3
    },
    {
      id: '3',
      title: 'Master Planner',
      description: 'Score 1000 points in Crop Planning',
      icon: 'award',
      reward: { coins: 300, experience: 500, items: ['Golden Watering Can'] },
      isUnlocked: false,
      progress: 0,
      requiredProgress: 1000
    }
  ]);

  const games = [
    {
      title: "Plant Master Challenge",
      description: "Test your farming knowledge and earn rewards",
      icon: Trophy,
      level: "Beginner",
      rewards: {
        coins: 50,
        experience: 100,
        items: ['Basic Seeds']
      }
    },
    {
      title: "Pest Control Strategy",
      description: "Learn to identify and manage common garden pests",
      icon: Target,
      level: "Intermediate",
      rewards: {
        coins: 100,
        experience: 200,
        items: ['Organic Pesticide']
      }
    },
    {
      title: "Crop Planning Puzzle",
      description: "Plan your garden layout for maximum yield",
      icon: Brain,
      level: "Advanced",
      rewards: {
        coins: 150,
        experience: 300,
        items: ['Premium Seeds']
      }
    }
  ];

  const handlePlayGame = (gameIndex: number) => {
    // Simulate completing a game
    const reward = games[gameIndex].rewards;
    setGameState(prev => ({
      ...prev,
      coins: prev.coins + reward.coins,
      experience: prev.experience + reward.experience,
      level: Math.floor((prev.experience + reward.experience) / 1000) + 1
    }));
  };

  return (
    <div className="container mx-auto p-4">
      {/* Player Stats */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 mb-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="flex items-center space-x-2">
            <Star className="w-6 h-6 text-yellow-500" />
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Level</p>
              <p className="text-xl font-bold">{gameState.level}</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Award className="w-6 h-6 text-purple-500" />
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Experience</p>
              <p className="text-xl font-bold">{gameState.experience}</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Coins className="w-6 h-6 text-yellow-500" />
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Coins</p>
              <p className="text-xl font-bold">{gameState.coins}</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Trophy className="w-6 h-6 text-green-500" />
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Achievements</p>
              <p className="text-xl font-bold">{achievements.filter(a => a.isUnlocked).length}/{achievements.length}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Games Grid */}
      <h2 className="text-2xl font-bold mb-6">Educational Games</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {games.map((game, index) => {
          const Icon = game.icon;
          return (
            <div key={index} className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow">
              <div className="flex items-center mb-4">
                <Icon className="w-8 h-8 text-green-500 mr-3" />
                <h3 className="text-xl font-semibold">{game.title}</h3>
              </div>
              <p className="text-gray-600 dark:text-gray-400 mb-4">{game.description}</p>
              
              {/* Rewards Preview */}
              <div className="mb-4 p-3 bg-gray-100 dark:bg-gray-700 rounded-lg">
                <p className="text-sm font-semibold mb-2">Rewards:</p>
                <div className="flex items-center space-x-4">
                  <div className="flex items-center">
                    <Coins className="w-4 h-4 text-yellow-500 mr-1" />
                    <span>{game.rewards.coins}</span>
                  </div>
                  <div className="flex items-center">
                    <Star className="w-4 h-4 text-purple-500 mr-1" />
                    <span>{game.rewards.experience} XP</span>
                  </div>
                </div>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-sm text-green-600 dark:text-green-400">{game.level}</span>
                <button 
                  onClick={() => handlePlayGame(index)}
                  className="btn btn-primary"
                >
                  Play Now
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Achievements */}
      <h2 className="text-2xl font-bold mt-8 mb-6">Achievements</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {achievements.map((achievement) => (
          <div 
            key={achievement.id}
            className={`bg-white dark:bg-gray-800 rounded-lg shadow p-4 ${
              achievement.isUnlocked ? 'border-2 border-green-500' : 'opacity-75'
            }`}
          >
            <div className="flex items-center mb-2">
              <Trophy className={`w-6 h-6 mr-2 ${
                achievement.isUnlocked ? 'text-green-500' : 'text-gray-400'
              }`} />
              <h3 className="font-semibold">{achievement.title}</h3>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
              {achievement.description}
            </p>
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center space-x-2">
                <Coins className="w-4 h-4 text-yellow-500" />
                <span>{achievement.reward.coins}</span>
                <Star className="w-4 h-4 text-purple-500 ml-2" />
                <span>{achievement.reward.experience} XP</span>
              </div>
              <span>{achievement.progress}/{achievement.requiredProgress}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};