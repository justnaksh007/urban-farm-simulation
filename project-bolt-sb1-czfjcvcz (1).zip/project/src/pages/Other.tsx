import React from 'react';
import { ShoppingBag, Book, Settings, HelpCircle } from 'lucide-react';

export const Other = () => {
  const sections = [
    {
      title: "Shop",
      icon: ShoppingBag,
      description: "Find gardening supplies and equipment",
      items: ["Seeds", "Tools", "Soil", "Containers"]
    },
    {
      title: "Resources",
      icon: Book,
      description: "Educational materials and guides",
      items: ["Tutorials", "Articles", "Videos", "Community Forum"]
    },
    {
      title: "Settings",
      icon: Settings,
      description: "Customize your experience",
      items: ["Profile", "Notifications", "Privacy", "Preferences"]
    },
    {
      title: "Help & Support",
      icon: HelpCircle,
      description: "Get assistance when needed",
      items: ["FAQ", "Contact Support", "Bug Report", "Feedback"]
    }
  ];

  return (
    <div className="container mx-auto p-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {sections.map((section, index) => {
          const Icon = section.icon;
          return (
            <div key={index} className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
              <div className="flex items-center mb-4">
                <Icon className="w-8 h-8 text-green-500 mr-3" />
                <h3 className="text-xl font-semibold">{section.title}</h3>
              </div>
              <p className="text-gray-600 dark:text-gray-400 mb-4">{section.description}</p>
              <ul className="grid grid-cols-2 gap-2">
                {section.items.map((item, itemIndex) => (
                  <li key={itemIndex} className="flex items-center">
                    <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                    <span className="text-gray-600 dark:text-gray-400">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          );
        })}
      </div>
    </div>
  );
};