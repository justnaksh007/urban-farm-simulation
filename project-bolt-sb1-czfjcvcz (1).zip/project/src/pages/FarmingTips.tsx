import React from 'react';
import { Sprout, Sun, Droplets, Bug } from 'lucide-react';

export const FarmingTips = () => {
  const categories = [
    {
      title: "Getting Started",
      icon: Sprout,
      tips: [
        "Choose the right containers for your space",
        "Select plants suitable for your climate",
        "Understand basic soil requirements"
      ]
    },
    {
      title: "Sunlight Management",
      icon: Sun,
      tips: [
        "Identify your space's sun exposure",
        "Rotate plants for even growth",
        "Use reflective surfaces to maximize light"
      ]
    },
    {
      title: "Watering Guide",
      icon: Droplets,
      tips: [
        "Water deeply but less frequently",
        "Check soil moisture before watering",
        "Use self-watering systems for consistency"
      ]
    },
    {
      title: "Pest Control",
      icon: Bug,
      tips: [
        "Identify common urban pests",
        "Use natural pest deterrents",
        "Practice companion planting"
      ]
    }
  ];

  return (
    <div className="container mx-auto p-4">
      <h2 className="text-2xl font-bold mb-6">Urban Farming Tips</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {categories.map((category, index) => {
          const Icon = category.icon;
          return (
            <div key={index} className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
              <div className="flex items-center mb-4">
                <Icon className="w-8 h-8 text-green-500 mr-3" />
                <h3 className="text-xl font-semibold">{category.title}</h3>
              </div>
              <ul className="space-y-3">
                {category.tips.map((tip, tipIndex) => (
                  <li key={tipIndex} className="flex items-start">
                    <span className="inline-block w-2 h-2 rounded-full bg-green-500 mt-2 mr-2"></span>
                    <span className="text-gray-600 dark:text-gray-400">{tip}</span>
                  </li>
                ))}
              </ul>
            </div>
          );
        })}
      </div>
    </div>
  );
};