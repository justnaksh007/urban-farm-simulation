import React from 'react';
import { Garden } from '../components/Garden';
import { WeatherWidget } from '../components/Weather';
import { Scaling as Seedling, ShoppingBag, BookOpen, Droplets, Plus, AlertTriangle } from 'lucide-react';
import type { Plant, Weather } from '../types';

export const Home = () => {
  const [plants, setPlants] = React.useState<Plant[]>([
    {
      id: '1',
      name: 'Tomato',
      stage: 'growing',
      health: 85,
      waterLevel: 70,
      lastWatered: new Date(),
      soilHealth: 90,
      plantedDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // 7 days ago
      nextAction: {
        type: 'water',
        dueIn: 4, // hours
      },
      growthProgress: 65,
      harvestDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000), // 14 days from now
    },
    {
      id: '2',
      name: 'Basil',
      stage: 'sprout',
      health: 95,
      waterLevel: 20,
      lastWatered: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      soilHealth: 85,
      plantedDate: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
      nextAction: {
        type: 'water',
        dueIn: 0,
      },
      growthProgress: 30,
      harvestDate: new Date(Date.now() + 21 * 24 * 60 * 60 * 1000),
    },
  ]);

  const [weather] = React.useState<Weather>({
    temperature: 24,
    humidity: 65,
    description: 'Partly Cloudy',
    icon: 'cloudy',
  });

  const handleWater = (plantId: string) => {
    setPlants(plants.map(plant =>
      plant.id === plantId
        ? { ...plant, waterLevel: Math.min(100, plant.waterLevel + 20) }
        : plant
    ));
  };

  const handleTreatPests = (plantId: string) => {
    setPlants(plants.map(plant =>
      plant.id === plantId
        ? { ...plant, health: Math.min(100, plant.health + 15) }
        : plant
    ));
  };

  const handleFertilize = (plantId: string) => {
    setPlants(plants.map(plant =>
      plant.id === plantId
        ? { ...plant, soilHealth: Math.min(100, plant.soilHealth + 20) }
        : plant
    ));
  };

  // Calculate garden stats
  const gardenStats = {
    totalPlants: plants.length,
    needsAttention: plants.filter(p => p.waterLevel < 30 || p.health < 30 || p.soilHealth < 30).length,
    averageHealth: Math.round(plants.reduce((acc, p) => acc + p.health, 0) / plants.length),
    nextHarvest: plants.reduce((earliest, p) => 
      p.harvestDate && (!earliest || p.harvestDate < earliest) ? p.harvestDate : earliest, 
      null as Date | null
    ),
  };

  return (
    <div className="space-y-6">
      {/* Garden Overview */}
      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">My Garden</h2>
          <button className="btn btn-primary flex items-center">
            <Plus className="w-4 h-4 mr-2" />
            Add Plant
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-green-100 dark:bg-green-900 p-4 rounded-lg">
            <p className="text-sm text-green-600 dark:text-green-400">Total Plants</p>
            <p className="text-2xl font-bold">{gardenStats.totalPlants}</p>
          </div>
          <div className="bg-amber-100 dark:bg-amber-900 p-4 rounded-lg">
            <p className="text-sm text-amber-600 dark:text-amber-400">Needs Attention</p>
            <p className="text-2xl font-bold">{gardenStats.needsAttention}</p>
          </div>
          <div className="bg-blue-100 dark:bg-blue-900 p-4 rounded-lg">
            <p className="text-sm text-blue-600 dark:text-blue-400">Average Health</p>
            <p className="text-2xl font-bold">{gardenStats.averageHealth}%</p>
          </div>
          <div className="bg-purple-100 dark:bg-purple-900 p-4 rounded-lg">
            <p className="text-sm text-purple-600 dark:text-purple-400">Next Harvest</p>
            <p className="text-2xl font-bold">
              {gardenStats.nextHarvest 
                ? new Date(gardenStats.nextHarvest).toLocaleDateString()
                : 'N/A'}
            </p>
          </div>
        </div>

        {gardenStats.needsAttention > 0 && (
          <div className="mb-6 p-4 bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-300 rounded-lg flex items-center">
            <AlertTriangle className="w-5 h-5 mr-2" />
            <span>{gardenStats.needsAttention} plants need your attention!</span>
          </div>
        )}

        <Garden
          plants={plants}
          onWater={handleWater}
          onTreatPests={handleTreatPests}
          onFertilize={handleFertilize}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="md:col-span-3">
          <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-lg">
            <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <button className="flex flex-col items-center justify-center p-4 bg-green-100 dark:bg-green-900 rounded-lg hover:bg-green-200 dark:hover:bg-green-800">
                <Seedling className="w-6 h-6 mb-2" />
                <span>Plant New</span>
              </button>
              <button className="flex flex-col items-center justify-center p-4 bg-blue-100 dark:bg-blue-900 rounded-lg hover:bg-blue-200 dark:hover:bg-blue-800">
                <ShoppingBag className="w-6 h-6 mb-2" />
                <span>Shop</span>
              </button>
              <button className="flex flex-col items-center justify-center p-4 bg-purple-100 dark:bg-purple-900 rounded-lg hover:bg-purple-200 dark:hover:bg-purple-800">
                <BookOpen className="w-6 h-6 mb-2" />
                <span>Learn</span>
              </button>
              <button className="flex flex-col items-center justify-center p-4 bg-cyan-100 dark:bg-cyan-900 rounded-lg hover:bg-cyan-200 dark:hover:bg-cyan-800">
                <Droplets className="w-6 h-6 mb-2" />
                <span>Hydroponics</span>
              </button>
            </div>
          </div>
        </div>
        
        <div className="md:col-span-1">
          <WeatherWidget weather={weather} />
        </div>
      </div>
    </div>
  );
};