import React from 'react';
import { Cloud, Sun, Wind, Droplets } from 'lucide-react';

export const Weather = () => {
  const forecast = [
    { day: 'Today', temp: 24, humidity: 65, wind: 12, icon: Sun },
    { day: 'Tomorrow', temp: 23, humidity: 70, wind: 10, icon: Cloud },
    { day: 'Wednesday', temp: 25, humidity: 60, wind: 15, icon: Sun },
    { day: 'Thursday', temp: 22, humidity: 75, wind: 8, icon: Cloud },
    { day: 'Friday', temp: 24, humidity: 68, wind: 11, icon: Sun }
  ];

  return (
    <div className="container mx-auto p-4">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 mb-6">
        <h2 className="text-2xl font-bold mb-4">Current Weather</h2>
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Sun className="w-16 h-16 text-yellow-500 mr-4" />
            <div>
              <p className="text-4xl font-bold">24°C</p>
              <p className="text-gray-600 dark:text-gray-400">Sunny</p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center">
              <Wind className="w-5 h-5 mr-2 text-blue-500" />
              <span>12 km/h</span>
            </div>
            <div className="flex items-center">
              <Droplets className="w-5 h-5 mr-2 text-blue-500" />
              <span>65%</span>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        {forecast.map((day, index) => {
          const Icon = day.icon;
          return (
            <div key={index} className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-4">
              <h3 className="text-lg font-semibold mb-2">{day.day}</h3>
              <Icon className="w-8 h-8 text-gray-600 dark:text-gray-400 mb-2" />
              <div className="space-y-1">
                <p className="text-xl font-bold">{day.temp}°C</p>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  <Droplets className="w-4 h-4 inline mr-1" />
                  {day.humidity}%
                </p>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  <Wind className="w-4 h-4 inline mr-1" />
                  {day.wind} km/h
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};