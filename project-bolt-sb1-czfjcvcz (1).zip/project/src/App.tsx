import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ThemeToggle } from './components/ThemeToggle';
import { Navigation } from './components/Navigation';
import { Home } from './pages/Home';
import { Games } from './pages/Games';
import { FarmingTips } from './pages/FarmingTips';
import { Weather } from './pages/Weather';
import { Other } from './pages/Other';
import { Scaling as Seedling } from 'lucide-react';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-100 dark:bg-gray-900 text-gray-900 dark:text-white">
        <header className="bg-white dark:bg-gray-800 shadow-lg">
          <div className="container mx-auto px-4 py-4">
            <div className="flex justify-between items-center">
              <div className="flex items-center space-x-2">
                <Seedling className="w-8 h-8 text-green-500" />
                <h1 className="text-2xl font-bold">Urban Farmer</h1>
              </div>
              <div className="flex items-center space-x-4">
                <Navigation />
                <ThemeToggle />
              </div>
            </div>
          </div>
        </header>

        <main className="container mx-auto px-4 py-8">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/games" element={<Games />} />
            <Route path="/tips" element={<FarmingTips />} />
            <Route path="/weather" element={<Weather />} />
            <Route path="/other" element={<Other />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;