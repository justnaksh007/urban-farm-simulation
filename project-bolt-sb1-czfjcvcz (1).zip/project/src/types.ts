export interface Plant {
  id: string;
  name: string;
  stage: 'seed' | 'sprout' | 'growing' | 'mature';
  health: number;
  waterLevel: number;
  lastWatered: Date;
  soilHealth: number;
  plantedDate: Date;
  nextAction?: {
    type: 'water' | 'fertilize' | 'pest-control';
    dueIn: number; // hours
  };
  growthProgress: number;
  harvestDate?: Date;
}

export interface Weather {
  temperature: number;
  humidity: number;
  description: string;
  icon: string;
}

export interface Shop {
  id: string;
  name: string;
  distance: string;
  rating: number;
  address: string;
}

export interface GameState {
  level: number;
  experience: number;
  coins: number;
  sustainabilityScore: number;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  reward: {
    coins: number;
    experience: number;
    items?: string[];
  };
  isUnlocked: boolean;
  progress: number;
  requiredProgress: number;
}

export interface GameReward {
  coins: number;
  experience: number;
  items?: string[];
  achievement?: Achievement;
}