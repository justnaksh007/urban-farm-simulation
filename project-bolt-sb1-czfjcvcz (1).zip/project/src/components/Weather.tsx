import React from 'react';
import { Cloud, Sun, Droplets } from 'lucide-react';
import type { Weather } from '../types';

interface WeatherWidgetProps {
  weather: Weather;
}

export const WeatherWidget: React.FC<WeatherWidgetProps> = ({ weather }) => {
  return (
    <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-lg">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Current Weather</h3>
          <p className="text-sm text-gray-600 dark:text-gray-400">{weather.description}</p>
        </div>
        {weather.icon === 'sunny' ? (
          <Sun className="w-8 h-8 text-yellow-500" />
        ) : (
          <Cloud className="w-8 h-8 text-gray-500" />
        )}
      </div>
      <div className="mt-4 grid grid-cols-2 gap-4">
        <div className="flex items-center">
          <Sun className="w-5 h-5 mr-2 text-orange-500" />
          <span>{weather.temperature}°C</span>
        </div>
        <div className="flex items-center">
          <Droplets className="w-5 h-5 mr-2 text-blue-500" />
          <span>{weather.humidity}%</span>
        </div>
      </div>
    </div>
  );
};