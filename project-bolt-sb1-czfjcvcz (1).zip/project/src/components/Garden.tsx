import React from 'react';
import { Plane as PlantIcon, Droplets, Bug, Sprout, Clock, AlertTriangle, Timer } from 'lucide-react';
import type { Plant } from '../types';

interface GardenProps {
  plants: Plant[];
  onWater: (plantId: string) => void;
  onTreatPests: (plantId: string) => void;
  onFertilize: (plantId: string) => void;
}

export const Garden: React.FC<GardenProps> = ({ plants, onWater, onTreatPests, onFertilize }) => {
  const getStageEmoji = (stage: Plant['stage']) => {
    switch (stage) {
      case 'seed': return '🌱';
      case 'sprout': return '🌿';
      case 'growing': return '🌺';
      case 'mature': return '🌳';
      default: return '🌱';
    }
  };

  const formatTimeLeft = (hours: number) => {
    if (hours < 1) return 'Due now';
    return `${Math.floor(hours)} hours`;
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {plants.map((plant) => (
        <div key={plant.id} className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg">
          <div className="flex justify-between items-start mb-4">
            <div className="flex items-center">
              <span className="text-2xl mr-2">{getStageEmoji(plant.stage)}</span>
              <div>
                <h3 className="text-lg font-semibold">{plant.name}</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Stage: {plant.stage.charAt(0).toUpperCase() + plant.stage.slice(1)}
                </p>
              </div>
            </div>
            {plant.nextAction && (
              <div className="flex items-center text-sm text-amber-500">
                <Clock className="w-4 h-4 mr-1" />
                <span>{formatTimeLeft(plant.nextAction.dueIn)}</span>
              </div>
            )}
          </div>

          <div className="space-y-3 mb-4">
            {/* Growth Progress */}
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Growth Progress</span>
                <span>{plant.growthProgress}%</span>
              </div>
              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                <div
                  className="bg-green-500 rounded-full h-2 transition-all duration-300"
                  style={{ width: `${plant.growthProgress}%` }}
                ></div>
              </div>
            </div>

            {/* Health */}
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Health</span>
                <span>{plant.health}%</span>
              </div>
              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                <div
                  className={`rounded-full h-2 transition-all duration-300 ${
                    plant.health > 70 ? 'bg-green-500' :
                    plant.health > 30 ? 'bg-yellow-500' : 'bg-red-500'
                  }`}
                  style={{ width: `${plant.health}%` }}
                ></div>
              </div>
            </div>

            {/* Water Level */}
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Water Level</span>
                <span>{plant.waterLevel}%</span>
              </div>
              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                <div
                  className="bg-blue-500 rounded-full h-2 transition-all duration-300"
                  style={{ width: `${plant.waterLevel}%` }}
                ></div>
              </div>
            </div>

            {/* Soil Health */}
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Soil Health</span>
                <span>{plant.soilHealth}%</span>
              </div>
              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                <div
                  className="bg-amber-600 rounded-full h-2 transition-all duration-300"
                  style={{ width: `${plant.soilHealth}%` }}
                ></div>
              </div>
            </div>
          </div>

          {/* Plant Info */}
          <div className="text-sm text-gray-600 dark:text-gray-400 mb-4">
            <div className="flex items-center mb-1">
              <Timer className="w-4 h-4 mr-2" />
              <span>Planted: {new Date(plant.plantedDate).toLocaleDateString()}</span>
            </div>
            {plant.harvestDate && (
              <div className="flex items-center">
                <Sprout className="w-4 h-4 mr-2" />
                <span>Expected harvest: {new Date(plant.harvestDate).toLocaleDateString()}</span>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2 justify-between">
            <button
              onClick={() => onWater(plant.id)}
              className={`flex-1 p-2 rounded-lg flex items-center justify-center ${
                plant.waterLevel < 30
                  ? 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300'
                  : 'bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-300'
              }`}
              disabled={plant.waterLevel >= 100}
            >
              <Droplets className="w-4 h-4 mr-1" />
              Water
            </button>
            <button
              onClick={() => onTreatPests(plant.id)}
              className={`flex-1 p-2 rounded-lg flex items-center justify-center ${
                plant.health < 50
                  ? 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300'
                  : 'bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-300'
              }`}
            >
              <Bug className="w-4 h-4 mr-1" />
              Treat
            </button>
            <button
              onClick={() => onFertilize(plant.id)}
              className={`flex-1 p-2 rounded-lg flex items-center justify-center ${
                plant.soilHealth < 50
                  ? 'bg-amber-100 text-amber-700 dark:bg-amber-900 dark:text-amber-300'
                  : 'bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-300'
              }`}
            >
              <Sprout className="w-4 h-4 mr-1" />
              Fertilize
            </button>
          </div>

          {/* Alerts */}
          {(plant.waterLevel < 30 || plant.health < 30 || plant.soilHealth < 30) && (
            <div className="mt-4 p-2 bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-300 rounded-lg flex items-center">
              <AlertTriangle className="w-4 h-4 mr-2" />
              <span className="text-sm">
                {plant.waterLevel < 30 && 'Needs water! '}
                {plant.health < 30 && 'Health critical! '}
                {plant.soilHealth < 30 && 'Soil needs attention!'}
              </span>
            </div>
          )}
        </div>
      ))}
    </div>
  );
};