import React from 'react';
import { Home, Gamepad2, Leaf, Cloud, Menu, MoreHorizontal } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

export const Navigation = () => {
  const location = useLocation();
  const [isOpen, setIsOpen] = React.useState(false);

  const navItems = [
    { path: '/', icon: Home, label: 'Home' },
    { path: '/games', icon: Gamepad2, label: 'Games' },
    { path: '/tips', icon: Leaf, label: 'Farming Tips' },
    { path: '/weather', icon: Cloud, label: 'Weather' },
    { path: '/other', icon: MoreHorizontal, label: 'Other' }
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <>
      {/* Desktop Navigation */}
      <nav className="hidden md:flex space-x-4">
        {navItems.map(({ path, icon: Icon, label }) => (
          <Link
            key={path}
            to={path}
            className={`flex items-center px-4 py-2 rounded-lg transition-colors ${
              isActive(path)
                ? 'bg-green-500 text-white'
                : 'hover:bg-gray-200 dark:hover:bg-gray-700'
            }`}
          >
            <Icon className="w-5 h-5 mr-2" />
            <span>{label}</span>
          </Link>
        ))}
      </nav>

      {/* Mobile Navigation */}
      <div className="md:hidden">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="p-2 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-700"
        >
          <Menu className="w-6 h-6" />
        </button>

        {isOpen && (
          <div className="absolute top-16 left-0 right-0 bg-white dark:bg-gray-800 shadow-lg z-50">
            {navItems.map(({ path, icon: Icon, label }) => (
              <Link
                key={path}
                to={path}
                onClick={() => setIsOpen(false)}
                className={`flex items-center px-4 py-3 ${
                  isActive(path)
                    ? 'bg-green-500 text-white'
                    : 'hover:bg-gray-200 dark:hover:bg-gray-700'
                }`}
              >
                <Icon className="w-5 h-5 mr-2" />
                <span>{label}</span>
              </Link>
            ))}
          </div>
        )}
      </div>
    </>
  );
};